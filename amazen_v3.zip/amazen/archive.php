<?php get_header(); ?>
	<div class="container bw">
		<div class="row">
			<div class="col-md-8 col-sm-8 col-xs-12">
			<ol class="breadcrumb">
				<li><a href="<?php bloginfo('url'); ?>"><i class="glyphicon glyphicon-home"></i></a></li>&#32;<span class="divider">&rsaquo;</span>&#32;
				<li class="active">Archives</li>&#32;<span class="divider">&rsaquo;</span>&#32;
				<li class="active"><?php the_time('F, Y'); ?></li>
			</ol>
				<div class="mw">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="ep">
						<div class="tl">
							<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
						</div>
						<div class="oh">
							<?php if ( has_post_thumbnail() ) { 
							echo '<a href="' . get_permalink( $post->ID ) . '" title="' . get_the_title( $post->ID ) . '">';
							echo get_the_post_thumbnail( $post->ID, 'thumbnail', array( 'class' => 'img-responsive' )); 
							echo '</a>';
							} else { ?>
								<a href="<?php the_permalink() ?>"><img <?php echo $bd;?> src="<?php bloginfo('template_url'); ?>/img/notfound.jpg" alt="image not available" height="150px" width="150px"></a>
							<?php } ?>
						</div>
						<div class="hc">
							<?php echo excerpt(16).'...'; ?>
						</div>
					</div>
				<?php endwhile; else: ?>
					<p><?php //_e('Maaf posting tidak tersedia'); ?></p>
				<?php endif; ?>
				</div><!-- /.mw -->
			</div><!-- /.col-md-8 col-sm-8 col-xs-12 -->
			<div class="col-md-4 col-sm-4 col-xs-12">
				<?php get_sidebar(''); ?>
			</div><!-- /.col-md-3 col-sm-4 col-xs-12 -->
		</div><!-- /.container -->
	</div><!-- /.row -->

	<div class="container">
		<div class="bw">	
			<div class="col-md-8 col-sm-8 col-xs-12">
				<ul class="pager">
					<li>
					<?php if (function_exists("pagination")) { pagination($additional_loop->max_num_pages);	}?>
					</li>
				</ul>
			</div><!-- /.col-md-8 col-sm-8 col-xs-12 -->
		</div><!-- /.container -->
	</div><!-- /.row -->
<?php get_footer(); ?>
<?php get_header(); ?>
	<div class="row">
		<div class="container bw">
			<div class="col-md-8 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="<?php bloginfo('url'); ?>"><i class="glyphicon glyphicon-home"></i></a></li>&#32;<span class="divider">&rsaquo;</span>&#32;
					<li class="active">Page </li>&#32;<span class="divider">&rsaquo;</span>&#32;
					<li class="active"><?php echo $post->post_title;?></li>
				</ol>
			<?php 
			if (have_posts()) : 
				while (have_posts()) : 
					the_post(); ?>
						<div class="tc">
							<h1><?php the_title(); ?></h1>
							<?php if ( has_post_thumbnail() ) : ?>
								<center>
								<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
										<?php the_post_thumbnail('large', array( 'class' => 'img-responsive')); ?>
								</a>
								</center>
							<?php endif; ?>		
							<?php 
							$phrase = get_the_content();
							$phrase = apply_filters('the_content', $phrase);
							$replace = '<p style="text-align: justify;margin-bottom:20px;font-size: 16px;line-height: 1.625em;">';
							echo str_replace('<p>', $replace, $phrase);
							?>							
						</div>							
			<?php endwhile; else: ?>
				<p><?php _e('Maaf posting tidak tersedia'); ?></p>
<?php endif; ?>	
			</div><!-- /.md-8 col-sm-8 col-xs-12 -->
			
			<div class="col-md-4 col-sm-4 col-xs-12">
				<?php get_sidebar(''); ?>
			</div><!-- /.col-md-3 col-sm-4 col-xs-12 -->
			
		</div><!-- /.container bw -->
	</div><!-- /.row -->
<?php get_footer(); ?>
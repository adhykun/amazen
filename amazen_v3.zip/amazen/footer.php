	<footer>
		<div class="container-fluid" style="text-align:center;background:#C2185B">
			<div class="pb">
			<ul><?php wp_list_pages('title_li=&depth=1'); ?></ul>
			<p>2017 &copy; <?php echo strtoupper(str_replace(array('http://','/'),'',get_site_url())); ?> | Amazen Theme By A.K </p><br />
			</div>
		</div>
	</footer>
	<?php echo get_option('hts'); echo get_option('anal'); wp_footer(); ?>
	<script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
</body>
</html> 
<?php get_header(); ?>
<?php 
$theq = $wp_query->query_vars['s'];
$stitle = ucwords(str_replace("-"," ", $theq));
?>
	<div class="container bw">
		<div class="row">
			<div class="col-md-8 col-sm-8 col-xs-12">
			<ol class="breadcrumb">
				<li><a href="<?php bloginfo('url'); ?>"><i class="glyphicon glyphicon-home"></i></a></li>&#32;<span class="divider">&rsaquo;</span>&#32;
				<li class="active">Search</li>&#32;<span class="divider">&rsaquo;</span>&#32;
				<li class="active"><?php echo $stitle; ?></li>
			</ol>
				<div class="mw">
					<div class="st">
						<h3>Showing <?php echo count($posts);?> Total Article, Relatd with "<?php echo $stitle; ?>"</h3>
					</div>
					<div class="ep">
					<?php
						include 'search-amazon.php';
					?>
					</div>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>		
					<!--<div class="ep">
						<div class="tl">
							<h2><a href="<?php //the_permalink() ?>" rel="bookmark" title="<?php //the_title(); ?>"><?php //the_title(); ?></a></h2>
						</div>
						<div class="oh">
							<?php //if ( has_post_thumbnail() ) { 
							//echo '<a href="' . get_permalink( $post->ID ) . '" title="' . get_the_title( $post->ID ) . '">';
							//echo get_the_post_thumbnail( $post->ID, 'thumbnail', array( 'class' => 'img-responsive' )); 
							//echo '</a>';
							//} else { ?>
								<a href="<?php //the_permalink() ?>"><img <?php //echo $bd;?> src="<?php //bloginfo('template_url'); ?>/img/notfound.jpg" alt="image not available" height="150px" width="150px"></a>
							<?php //} ?>
						</div>
						<div class="hc">
							<?php //echo excerpt(16).'...'; ?>
						</div>
					</div>-->
				<?php endwhile; else: ?>
					<aside style="margin:35px 0 20px;">
						<form role="search" method="get" id="searchform" class="searchform" action="<?php bloginfo('url'); ?>/">
							<div class="form-group">
								<input type="text" name="s" id="s" class="form-control" placeholder="Type and hit Enter to Search Again">
								<input id="searchsubmit" value="Search" type="hidden" />
							</div>
						</form>						
					</aside>
				<?php endif; ?>
				</div><!-- /.mw -->
			</div><!-- /.col-md-8 col-sm-8 col-xs-12 -->
			<div class="col-md-4 col-sm-4 col-xs-12">
				<?php get_sidebar(''); ?>
			</div><!-- /.col-md-3 col-sm-4 col-xs-12 -->
		</div><!-- /.row -->
	</div><!-- /.container -->

	<div class="container">
		<div class="row">	
			<div class="col-md-8 col-sm-8 col-xs-12">
				<ul class="pager">
					<li>
					<?php if (function_exists("pagination")) { pagination($additional_loop->max_num_pages);	}?>
					</li>
				</ul>
			</div><!-- /.col-md-8 col-sm-8 col-xs-12 -->
		</div><!-- /.row -->
	</div><!-- /.container -->
<?php get_footer(); ?>
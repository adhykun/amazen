<div id="sidebar">
	<ul>
			<aside style="margin:35px 0 20px;">
				<li>
				<form role="search" method="get" id="searchform" class="searchform" action="<?php bloginfo('url'); ?>/">
					<div class="form-group">
						<input type="text" name="s" id="s" class="form-control" placeholder="Type and hit Enter">
						<input id="searchsubmit" value="Search" type="hidden" />
					</div>
				</form>						
				</li>
			</aside>
		<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
			<div id="secondary" class="widget-area" role="complementary">
				<?php dynamic_sidebar( 'sidebar-1' ); ?>
			</div>
		<?php endif; ?>
	</ul>
</div>
<!-- #sidebar END -->
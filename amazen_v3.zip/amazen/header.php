<!DOCTYPE html>
<html lang="en">
<head profile="http://gmpg.org/xfn/11">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php echo get_option('gmet').''.get_option('bmet').''.get_option('pmet'); ?>
	<title><?php if(is_home()){bloginfo('name');echo ' &raquo; ';bloginfo('description');}elseif(is_category()){single_cat_title();echo ' &raquo; ';bloginfo('name');}elseif(is_single()&&!is_attachment()){single_post_title();echo ' &raquo; ';bloginfo('name');}elseif(is_page()){single_post_title();echo ' Page : ';bloginfo('name');}elseif(is_single()&&is_attachment()){$ti=wp_title('',true);echo ucwords(str_replace(array('-','_','+'),' ',$ti));}elseif(is_tag()||is_archive()){wp_title('',true);echo ' &raquo; ';bloginfo('name');}else {wp_title('',true);}?></title>
	<meta name="description" content="<?php if(is_home()){bloginfo('name');echo ' ';bloginfo('description');}elseif(is_category()){single_cat_title();echo ' ';bloginfo('name');}elseif(is_single()&&!is_attachment()){single_post_title();echo ' ';bloginfo('name');}elseif(is_page()){single_post_title();echo ' Page : ';bloginfo('name');}elseif(is_single()&&is_attachment()){$ti=wp_title('',true);echo ucwords(str_replace(array('-','_','+'),' ',$ti));}elseif(is_tag()||is_archive()){wp_title('',true);echo ' ';bloginfo('name');}else {wp_title('',true);}?>"/>
	<meta name="keywords" content="<?php if(is_home()){bloginfo('name');echo ', ';bloginfo('description');}elseif(is_category()){single_cat_title();echo ', ';bloginfo('name');}elseif(is_single()&&!is_attachment()){single_post_title();echo ', ';bloginfo('name');}elseif(is_page()){single_post_title();echo ' Page : ';bloginfo('name');}elseif(is_single()&&is_attachment()){$ti=wp_title('',true);echo ucwords(str_replace(array('-','_','+'),' ',$ti));}elseif(is_tag()||is_archive()){wp_title('',true);echo ', ';bloginfo('name');}else {wp_title('',true);}?>"/>
	<?php wp_head(); ?>
	<link href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php bloginfo('template_url'); ?>/style.css" rel="stylesheet">
	<link href="<?php bloginfo('template_url'); ?>/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
	<script src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
</head>
<body style="background:#<?php echo get_option('bgcolor');?>;">
	<style type="text/css">
	body a {color:<?php echo '#'.get_option('lcol')?>;}
	</style>
	<div class="container">
		<div class="row">
			<nav class="navbar navbar-default" style="background:#<?php echo get_option('tmcolor');?>;">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1><a class="navbar-brand" href="<?php bloginfo('url'); ?>"><?php echo str_replace(array('http://','/'),'',get_site_url()); ?></a></h1>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling 
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
						<?php //$ctg=explode("<br />",wp_list_categories('title_li=&echo=0&depth=1'));foreach($ctg as $cts){echo str_replace('</li>','</li><li role="separator" class="divider"></li>',$cts);}?>
						</ul>
					</div><!-- /.navbar-collapse -->
					<?php 
					if ( has_nav_menu(  'primary' ) ) {
							wp_nav_menu( array( 'theme_location' => 'primary','container' => 'div' , 'container_class' => 'collapse navbar-collapse', 'container_id' => 'bs-example-navbar-collapse-1','menu_class' => 'nav navbar-nav' ) );
						}
						else
						{}
					?>	
			</nav>
		</div><!-- /.row -->
	</div><!-- /.container -->
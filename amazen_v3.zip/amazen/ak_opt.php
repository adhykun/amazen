<?php 
//Set texdomain 
add_action('init', 'ak_textom');
function ak_textom() {
  load_plugin_textdomain('amazen', false, 'amazen');
}

// Create Main Menu
add_action('admin_menu', 'ak_menu');
function ak_menu() {
	//create new top-level menu
	add_menu_page(
		__('Amazen Settings Option', 'amazen'), //Page Title, textdomain
		__('Amazen Options', 'amazen'), //Menu Label, textdomain
		'manage_options',  //Privilege
		'amazen-settings-page', //Slug
		'amazen_settings_page', //Function Page
		get_template_directory_uri ().'/img/b.png'	
	);
}

//call register settings function
add_action( 'admin_init', 'register_amazen_settings' );
function register_amazen_settings() {
	//register our settings
	register_setting( 'io-settings', 'gmet' );
	register_setting( 'io-settings', 'bmet' );
	register_setting( 'io-settings', 'pmet' );
	
	register_setting( 'io-settings', 'ads7' );
	
	register_setting( 'io-settings', 'hts' );
	register_setting( 'io-settings', 'anal' );

	register_setting( 'io-settings', 'bgcolor' );
	register_setting( 'io-settings', 'tmcolor' );
	register_setting( 'io-settings', 'lcol' );
	register_setting( 'io-settings', 'sdcolor' );
	
	register_setting( 'io-settings', 'gbox' );

}

function amazen_settings_page() {
	if (isset($_REQUEST['settings-updated'])) {
	echo'<div class="updated" style="padding:10px;margin-top:10px;">Setting Saved</div>';
	} else {
	} 
?>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory') ?>/js/jscolor.js"></script>
<div class="wrap">
<?php $lcol =  get_option('lcol'); ?>
<form action="options.php" method="post">
<?php settings_fields('io-settings');do_settings_sections('io-settings');?>
	<table class="form-table">
		<h3 style="color:#<?php echo $lcol?>;font-size:20px;">Color Style </h3>
		<tr>
		<th scope="row" style="font-size:12px;">BG Color :</th>
		<td><input style="width:200px;" name="bgcolor" type="colorjs" value="<?php if ( get_option('bgcolor') == "") { echo 'F8BBD0'; } else { echo get_option('bgcolor'); } ?>" class="color"/>
		</td>
		</tr>
		<tr>
		<th scope="row" style="font-size:12px;">Top Menu & Foot BG Color :</th>
		<td><input style="width:200px;" name="tmcolor" type="colorjs" value="<?php if ( get_option('tmcolor') == "") { echo 'E91E63'; } else { echo get_option('tmcolor'); } ?>" class="color"/></td>
		</tr>
		<tr>
		<th scope="row" style="font-size:12px;">Link Color :</th>
		<td><input style="width:200px;" name="lcol" type="colorjs" value="<?php if ( get_option('lcol') == "") { echo '007ACC'; } else { echo get_option('lcol'); } ?>" class="color"/></td>
		</tr>
		<tr>
		<th scope="row" style="font-size:12px;">Sidebar BG Color :</th>
		<td><input style="width:200px;" name="sdcolor" type="colorjs" value="<?php if ( get_option('sdcolor') == "") { echo 'CE5708'; } else { echo get_option('sdcolor'); } ?>" class="color"/></td>
		</tr>
	</table>
<hr />
	<table class="form-table">
		<h3 style="color:#<?php echo $lcol?>;font-size:20px;">Meta Verification</h3>
		<tr>
		<th scope="row" style="font-size:12px;">Google Meta Verification : </th>
		<td><textarea style="padding:5px;width:550px;height:55px;" name="gmet"><?php echo get_option('gmet') ?></textarea></td>
		</tr>
		<tr>
		<th scope="row" style="font-size:12px;">Bing Meta Verification : </th>
		<td><textarea style="padding:5px;width:550px;height:55px;" name="bmet"><?php echo get_option('bmet') ?></textarea></td>
		</tr>
		<tr>
		<th scope="row" style="font-size:12px;">Pinterest Meta Verification : </th>
		<td><textarea style="padding:5px;width:550px;height:55px;" name="pmet"><?php echo get_option('pmet') ?></textarea></td>
		</tr>
	</table>
<hr />
	<table class="form-table">
		<h3 style="color:#<?php echo $lcol?>;font-size:20px;">Ads Code </h3>
		<tr>
		<th scope="row" style="font-size:12px;">Ads Responsive :</th>
		<td><textarea style="padding:5px;width:550px;height:150px;" name="ads7"><?php echo get_option('ads7') ?></textarea></td>
		</tr>
	</table>	
<hr />
	<table class="form-table">
		<h3 style="color:#<?php echo $lcol?>;font-size:20px;">Stats Code</h3>
		<tr>
		<th scope="row" style="font-size:12px;">Histats : </th>
		<td><textarea style="padding:5px;width:550px;height:150px;" name="hts"><?php echo get_option('hts') ?></textarea></td>
		</tr>
		<tr>
		<th scope="row" style="font-size:12px;">Analytic : </th>
		<td><textarea style="padding:5px;width:550px;height:150px;" name="anal"><?php echo get_option('anal') ?></textarea></td>
		</tr>
		<tr>
	</table>
<hr />
	<table class="form-table">
		<h3 style="color:#<?php echo $mcol?>;font-size:20px;">Single Post Setting</h3>
		<tr>
		<th scope="row" style="font-size:12px;">Show Featured Image on Single Post</th>
		<td>
		<select name="gbox" class="form-control">
			<option>---</option>
			<option <?php if (get_option('gbox') == 'yes') { ?>selected="true" <?php }; ?> value="yes">Yes</option>
			<option <?php if (get_option('gbox') == 'no') { ?>selected="true" <?php }; ?> value="no">No</option>
		</select>
		</td>
		</tr>
	</table>
<hr />
	<input type="submit" name="save" class="button-primary" value="Save Changes">
</form>
</div>
<?php }
?>
<?php get_header(); ?>
<?php 
	$cts=get_the_category('');
	$ctl="";
	$ctn="";
	$ctg="";
	foreach($cts as $ct){
		$ctl.= get_category_link($ct->term_id);
		$ctn.=$ct->cat_name.' ';
		$ctg.='<a href="'.get_category_link($ct->term_id).'">'.$ct->cat_name.'</a> ';
	}
	$ctl.="";
	$ctn.="";
	$ctg.="";
?>
	<div class="container bw">
		<div class="row">
			<div class="col-md-8 col-sm-8 col-xs-12">
				<ol class="breadcrumb">
					<li><a style="color:<?php echo '#'.get_option('mcol')?>" href="<?php bloginfo('url'); ?>"><i class="glyphicon glyphicon-home"></i></a></li>&#32;<span class="divider">&rsaquo;</span>&#32;
					<li class="active"><?php echo $ctg;?></li>	
				</ol>
			<?php 
			if (have_posts()) : 
				while (have_posts()) : 
					the_post(); 
					include('single-amazon.php');
					?>
					
						<div class="tc">
							<h1><?php the_title(); ?></h1>
							<?php
							if (empty($ads7)) {
							} else {	
							echo'<center><div class="adh">'.$ads7.'</div></center>';
							}?>
							<?php 
							$gbox = get_option('gbox');
							if ( $gbox == 'yes') { ?>
								<center>
									<img width="250px" height="auto" src="<?php echo get_post_meta($post->ID, "image", $single = true); ?>" />
								</center>							
					<?php	} else {} ?>
					
							<div class="pl">
								<div class="hc">
										<?php the_content(); ?>
								</div>
							</div>
							<div class="pr">
								<div class="prd">
									<div class="prz"><b>Price : <?php echo get_post_meta($post->ID, "price", $single = true); ?></b></div>
									<div class="mor">(Min. Order: 1 Piece)</div>
									<div class="btn-group"> 
										<button type="button" class="btn btn-danger" onclick="window.open('https://www.amazon.com/gp/product/<?php echo get_post_meta($post->ID, "asin", $single = true); ?>/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=<?php echo get_post_meta($post->ID, "asin", $single = true); ?>&linkCode=as2&tag=mijong-20&linkId=c535a10d9f2e5680f211ecc31c5a8d4f','_blank')">View Detail</button>
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
		
						</div>
						<div class="sh">
						<a class="fbs pull-left" href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" title="Share on Facebook!" target="_blank"><i class="fa fa-facebook"></i> Bagikan</a>
						<a class="twt pull-right" href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>&amp;text=<?php echo $post->post_title;?>&amp;via=<?php echo str_replace(array('http://','/'),'',get_site_url()); ?>" title="Tweet this!" target="_blank"><i class="fa fa-twitter"></i> Bagikan</a>
						</div>
						
						<div class="fb-comments img-responsive" data-href="<?php the_permalink(); ?>" data-width="100%" data-numposts="5" data-colorscheme="light"></div>
							<?php
							if (empty($ads7)) {
							} else {	
							echo'<center><div class="adh">'.$ads7.'</div></center>';
							}?>						
						<div class="lp">
							<h3>Others Product</h3>
							<?php 
								$cats = get_the_category(); $cat = $cats[0]; $cat = $cat->cat_ID;
								$rp = get_posts('numberposts=5&offset=0&orderby=rand&order=DESC&category='.$cat);
								$c = 0;
								foreach ( $rp as $po ) {
								//print_r ($po);
 									if ( $po->ID == $post->ID ) {
										//echo $post->ID;
										unset($po);
									} else {
										//print_r ($po); ?>
										<ul>
											<li>
												<a href="<?php echo get_permalink($po->ID); ?>" alt="<?php echo $po->post_title;?>"><img class="img-responsive" src="<?php echo get_post_meta($post->ID, "image", $single = true); ?>" alt="image not available" height="110px" width="120px"></a>
												<a href="<?php echo get_permalink($po->ID); ?>" target="_blank"><?php echo $po->post_title;?></a>
											</li><div class="clearfix"></div>
										</ul>
					<?php		} 
									//echo $c;
								$c++;
								}
								wp_reset_query();
								?>										
						</div>
						
			<?php endwhile; else: ?>
				<p><?php _e('Maaf posting tidak tersedia'); ?></p>
<?php endif; ?>	
			</div><!-- /.md-8 col-sm-8 col-xs-12 -->
			
			<div class="col-md-4 col-sm-4 col-xs-12">
				<?php get_sidebar(''); ?>
			</div><!-- /.col-md-3 col-sm-4 col-xs-12 -->
			
		</div><!-- /.row -->
	</div><!-- /.container bw -->
<div id="fb-root"></div><script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script>
<?php get_footer(); ?>
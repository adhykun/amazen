<?php get_header(); ?>
	<div class="row">
		<div class="container bw">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li><a href="<?php bloginfo('url'); ?>"><i class="glyphicon glyphicon-home"></i></a></li>&#32;<span class="divider">&rsaquo;</span>&#32;
					<li class="active">Page Not Found</li>
				</ol>
				<div class="tc">
					<center><img style="margin-top:30px;" class="img-responsive" src="<?php bloginfo('template_url'); ?>/img/notf.jpg"/></center>
				</div>
				<div id="sidebar">
					<h3 style="text-align:center;">Try Search What You Want Here<h3/>
					<ul>
						<aside style="margin:20px 0 50px;">
							<li>
							<form role="search" method="get" id="searchform" class="searchform" action="<?php bloginfo('url'); ?>/">
								<div class="form-group">
									<input type="text" name="s" id="s" class="form-control" placeholder="Type and hit Enter">
									<input id="searchsubmit" value="Search" type="hidden" />
								</div>
							</form>						
							</li>
						</aside>
					<ul>
					</div>
				
			</div>
		</div>
	</div>

	<!--<div class="container">
			<ol class="breadcrumb">
				<li><a style="color:<?php //echo '#'.get_option('mcol')?>" href="<?php //echo $siteurl; ?>"><i class="glyphicon glyphicon-home"></i></a></li>&#32;<span class="divider">&rsaquo;</span>&#32;
				<li class="active">Page Not Found</li>
			</ol>

			<div class="col-md-12 col-sm-12 col-xs-12 pull-right">
				<div class="row">
					<div style="margin:10px">
							<form role="search" method="get" id="searchform" class="searchform" action="<?php //bloginfo('url'); ?>/">
								<div class="form-group">
									<input type="text" name="s" id="s" class="form-control" placeholder="Type and hit Enter">
									<input id="searchsubmit" value="Search" type="hidden" />
								</div>
							</form>
							<img style="margin-top:30px" class="img-responsive" src="http://localhost/e/wp-content/themes/io/img/io_404.jpg"/>
					</div>
				</div>
			</div>

		</div>-->
<?php get_footer(); ?>
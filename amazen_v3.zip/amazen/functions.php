<?php
include('amazon/amazon-core.php');
$ads7 = get_option('ads7');
$ads3 = get_option('ads3');
add_theme_support( 'post-thumbnails' );
register_nav_menus( array(  
'primary' => __( 'Menu di Head', 'amazen' )
) );
/*--------
	Excerpt
----------*/
function excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'';
  } else {
    $excerpt = implode(" ",$excerpt);
  }	
  $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
  return $excerpt;
}

/*------------------------
	Register Sidebar Widget
--------------------------*/
function reg_amazen_bar() {
	register_sidebar( array(
		'name' => __( 'Amazen Wp Theme Sidebar' ),
		'id' => 'sidebar-1',
		'description' => __( 'Sidebar appears on the right side on home, single, archieve, tag and category page' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s" style="background:#'.get_option('sdcolor').';border: 1px solid #CFE9FF;margin-bottom:15px;">',
		'after_widget' => '</aside>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	}

add_action( 'widgets_init', 'reg_amazen_bar' );

/*---------------------------
	Recent Post with Thumbnail
-----------------------------*/
// Creating the widget 
class amazen_rec_po_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
		// Base ID of your widget
		'amazen_rec_po_widget', 

		// Widget name will appear in UI
		__('Amazen_Recent_Post'), 

		// Widget description
		array( 'description' => __( 'Custom Amazen Recent Post with Thumbnail' ), ) 
		);
	}

	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		$pc = $instance[ 'post_count' ];
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title'];

		$postslist = get_posts('numberposts='.$pc.'&order=DESC&orderby=date');
		foreach ($postslist as $p) :
			//print_r ($p);
			$tl = $p->post_title ;
			$at = $p->post_author;
			$dt = $p->post_date;
			$pid = $p->ID;

		?>
				<ul class="th_li">
					<li class="io-thumb-post">
						<a href="<?php echo get_permalink( $pid );?>">
								<img class="img-responsive" src="<?php echo get_post_meta($pid, "image", $single = true); ?>" alt="<?php echo substr($tl,0,55);?>" height="110px" width="120px">
						</a>
						<div class="thumbdet">
							<a href="<?php echo get_permalink( $pid );?>" title="<?php echo substr($tl,0,55);?>"><?php echo substr($tl,0,55);?></a>
						</div>
						<!--<span class="th_met">By <?php //the_author($pid);?> on <?php //echo get_the_time('F jS, Y',$p->ID) ?></span>-->
					</li>
				</ul>
				<div class="clearfix mb"></div>
	<?php endforeach;
	
		echo $args['after_widget'];
	}
			
	// Widget Backend 
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
			$pc = $instance[ 'post_count' ];
		} else {
			$title = __( 'Recent Post');
		}
		// Widget admin form
		?>
		<p>
		<label>Judul Widget ( harus diisi ! )</label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
		<label>Jumlah post ( masukan angka ! )</label> 
		<input name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $pc ); ?>" size="3"/>
		</p>
		<?php 
	}
		
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
		return $instance;
	}
} // Class amazen_rec_po_widget ends here


/* ---
	Add widget random post thumbnail
---- */
// Creating the widget 
class amazen_rand_po_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
		// Base ID of your widget
		'amazen_rand_po_widget', 

		// Widget name will appear in UI
		__('Amazen_Random_Post'), 

		// Widget description
		array( 'description' => __( 'Custom Amazen Random Post with Thumbnail' ), ) 
		);
	}

	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		$pc = $instance[ 'post_count' ];
		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( ! empty( $title ) )
		echo $args['before_title'] . $title . $args['after_title'];
		
		// This is where you run the code and display the output
		$postslist = get_posts('numberposts='.$pc.'&orderby=rand');
		foreach ($postslist as $p) :
			//print_r ($p);
			$tl = $p->post_title ;
			$gid = $p->guid ;
			$tn = $p->post_name;
			$at = $p->post_author;
			$dt = $p->post_date;
			$pid = $p->ID;

		?>
				<ul class="th_li">
					<li class="io-thumb-post">
						<a href="<?php echo get_permalink( $pid );?>">
							<img class="img-responsive" src="<?php echo get_post_meta($pid, "image", $single = true); ?>" alt="<?php echo substr($tl,0,55);?>" height="110px" width="120px">
						</a>
						<div class="thumbdet">
							<a href="<?php echo $gid;?>" title="<?php echo substr($tl,0,55);?>"><?php echo substr($tl,0,55);?></a>
						</div>
						<!--<span class="th_met">By <?php //the_author($pid);?> on <?php //echo get_the_time('F jS, Y',$p->ID) ?></span>-->
					</li>
				</ul>
				<div class="clearfix mb"></div>
	<?php endforeach;
	
		echo $args['after_widget'];
	}
			
	// Widget Backend 
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
			$pc = $instance[ 'post_count' ];
		} else {
			$title = __( 'Random Post');
		}
		// Widget admin form
		?>
		<p>
		<label>Judul Widget ( harus diisi ! )</label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
		<label>Jumlah post ( masukan angka ! )</label> 
		<input name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $pc ); ?>" size="3"/>
		</p>
		<?php 
	}
		
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
		return $instance;
	}
} // Class amazen_rand_po_widget ends here


// Register and load the widget
function wpb_load_widget() {
	register_widget( 'amazen_rec_po_widget' );
	register_widget( 'amazen_rand_po_widget' );
}
add_action( 'widgets_init', 'wpb_load_widget' );

// ------- gallery single -------- //
function gs($args = array()){
	
	$get_posts_args = array(
	"post_parent"=> get_the_ID(),
	"post_type"=>"attachment",
	"showposts"=>-1,
	"post_mime_type"=>"image/jpeg,image/jpg,image/gif,image/png");
	$posts = get_posts($get_posts_args);
	foreach ($posts as $post)
	{
		$parent = get_post($post->post_parent);
		if(($imgsrc = wp_get_attachment_image($post->ID, 'thumbnail', array( 'class' => 'img-responsive'))) 
				&& ($imglink= get_attachment_link($post->ID))
				&& $parent->post_status == "publish")
		{
			echo  "<a href='" . $imglink . "'>".$imgsrc."</a>" ;
		}
	}
}

// -------- page navigator ---------- //
function pagination($pages = '', $range = 4){  
     $showitems = ($range * 2)+1;
     global $paged;
     if(empty($paged)) $paged = 1;
     if($pages == ''){
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages) {
             $pages = 1;
         }
     }   
 
     if(1 != $pages){
         echo "<span class=\"disabled\">Page ".$paged." of ".$pages."</span>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo; First</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo; Previous</a>";
 
         for ($i=1; $i <= $pages; $i++){
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
                 echo ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
             }
         }
 
         if ($paged < $pages && $showitems < $pages) echo "<a href=\"".get_pagenum_link($paged + 1)."\">Next &rsaquo;</a>";  
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>Last &raquo;</a>";
     }
}
/*----------------
	Ak Theme Option
------------------*/
include (TEMPLATEPATH.'/ak_opt.php');
?>
<?php get_header(); ?>
	<div class="container bw">
		<div class="row">
			<div class="col-md-8 col-sm-8 col-xs-12">
			<ol class="breadcrumb">
				<li><a href="<?php bloginfo('url'); ?>"><i class="glyphicon glyphicon-home"></i></a></li>&#32;<span class="divider">&rsaquo;</span>&#32;
				<li class="active">Category</li>&#32;<span class="divider">&rsaquo;</span>&#32;
				<li class="active"><?php echo $wp_query->queried_object->name;?></li>
			</ol>
				<div class="mw">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="ep">
						<div class="tl">
							<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
						</div>
						<div class="pl">
							<div class="oh">
									<a href="<?php the_permalink() ?>"><img class="img-responsive" src="<?php echo get_post_meta($post->ID, "image", $single = true); ?>"/></a>
							</div>
							<div class="hc">
								<?php the_content(); ?>
							</div>
						</div>
						<div class="pr">
							<div class="prd">
								<div class="prz"><b>Price : <?php echo get_post_meta($post->ID, "price", $single = true); ?></b></div>
								<div class="mor">(Min. Order: 1 Piece)</div>
								<div class="btn-group"> 
									<button type="button" class="btn btn-danger" onclick="window.open('https://www.amazon.com/gp/product/<?php echo get_post_meta($post->ID, "asin", $single = true); ?>/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=<?php echo get_post_meta($post->ID, "asin", $single = true); ?>&linkCode=as2&tag=mijong-20&linkId=c535a10d9f2e5680f211ecc31c5a8d4f','_blank')">View Detail</button>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
											
					</div>
				<?php endwhile; else: ?>
					<p><?php //_e('Maaf posting tidak tersedia'); ?></p>
				<?php endif; ?>
				</div><!-- /.mw -->
			</div><!-- /.col-md-8 col-sm-8 col-xs-12 -->
			<div class="col-md-4 col-sm-4 col-xs-12">
				<?php get_sidebar(''); ?>
			</div><!-- /.col-md-3 col-sm-4 col-xs-12 -->
		</div><!-- /.container -->
	</div><!-- /.row -->

	<div class="container">
		<div class="row">	
			<div class="col-md-8 col-sm-8 col-xs-12">
				<ul class="pager">
					<li>
					<?php if (function_exists("pagination")) { pagination($additional_loop->max_num_pages);	}?>
					</li>
				</ul>
			</div><!-- /.col-md-8 col-sm-8 col-xs-12 -->
		</div><!-- /.container -->
	</div><!-- /.row -->
<?php get_footer(); ?>